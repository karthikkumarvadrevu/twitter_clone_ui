import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {
  registrationurl: string = "http://localhost:5077/api/Users";

  constructor(private http: HttpClient) { }
  registerUser(user: any): Observable<any> {

    return this.http.post(this.registrationurl, user);
  }
}
