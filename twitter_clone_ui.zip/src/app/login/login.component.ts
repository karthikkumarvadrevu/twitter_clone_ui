import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { RegistrationComponent } from '../registration/registration.component';
import { AuthenticationService } from '../authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  password: string = '';
  name: string = '';
  email: string = '';
  errormessage: string = '';

  constructor(private authservice: AuthenticationService, private router: Router) { }

  onSubmit(email: string, password: string) {
    this.authservice.login(email, password).subscribe(
      (response) => {
        console.log('Invoked ', response);
        if (response && response.token) {
          localStorage.setItem('token', response.token);
          localStorage.setItem('Userid', response.userid);
          this.router.navigate(['/']);

        }
        (errorResponse: any) => {
          console.log('errorResponse');
          if (errorResponse.status == 401) { this.errormessage = 'Invalid Credentials' };
        }


        // else{
        //   console.log('Authentication failure');        
        //   //this.router.navigate(['/login']);
        //   this.erorrmessage= 'Invalid Crdetnails';
        //return this.erorrmessage;
      }

    )
  }
}

