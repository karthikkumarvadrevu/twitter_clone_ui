import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})


export class GettweetsService {
  [x: string]: any;
  private apiUrl = 'http://localhost:5077/api/tweets/GetTweet/';


  constructor(private http: HttpClient) { }

  getTweetsbyUser(): Observable<any> {
    const loggedinuserid = localStorage.getItem('Userid')
    if (loggedinuserid) {
      let userid = +loggedinuserid;
      console.log('invoked');

      return this.http.get(this.apiUrl + userid);
    }
    else
      throw new Error('Logged In user not found')
  }

}

@Injectable({
  providedIn: 'root'
})

export class getallusertweetsservice {
  [x: string]: any;
  private apiUrl = 'http://localhost:5077/api/tweets';

  constructor(private http: HttpClient) { }

  getallusertweets(): Observable<any> {
    console.log('invoked');


    return this.http.get(this.apiUrl);
  }
}



@Injectable({
  providedIn: 'root'
})

export class createretweetService {
  private apiUrl = 'http://localhost:5077/api/Retweets/PostRetweet';
  showCommentBox = false;
  constructor(private http: HttpClient) { }

  createretweets(id: number): Observable<any> {
    console.log('invoked createretweets');
    const loggedinuserid = localStorage.getItem('Userid');
    console.log(loggedinuserid);
    if (loggedinuserid) {
      let userid = +loggedinuserid;
      console.log(userid);
      const tweetData = { userId: userid, originaltweetid: id };
      console.log(tweetData);
      console.log(this.http.post(this.apiUrl, tweetData));
      return this.http.post(this.apiUrl, tweetData);
    }
    else
      throw new Error('NO user id found');
  }

  private commenturl = 'http://localhost:5077/api';
  comment(comment: string, tweetid: number): Observable<any> {

    const loggedinuserid = localStorage.getItem('Userid');
    console.log(loggedinuserid);
    if (loggedinuserid) {

      let userid = +loggedinuserid;
      const tweetData = { tweetid: tweetid, userId: userid, commenttext: comment };
      return this.http.post(this.commenturl + '/Comments', tweetData);
    }
    else
      throw new Error('No user id found');
  }


  private likeurl = 'http://localhost:5077/api';
  liketweet(tweetid: number): Observable<any> {

    const loggedinuserid = localStorage.getItem('Userid');
    console.log(loggedinuserid);
    if (loggedinuserid) {

      let userid = +loggedinuserid;
      const tweetData = { userid: userid, tweetid: tweetid };
      return this.http.post(this.likeurl + '/Likes/PostLike', tweetData);
    }
    else
      throw new Error('No user id found');
  }





  private getcommenturl = 'http://localhost:5077/api';
  gettweetcomments(tweetid: number): Observable<any> {

    const loggedinuserid = localStorage.getItem('Userid');

    console.log(loggedinuserid);

    console.log('invoked gettweetcomments');

    if (tweetid) {
      let currenttweetid = +tweetid;


      if (loggedinuserid) {
        let userid = +loggedinuserid;
        const tweetData = { tweetid: currenttweetid };
        return this.http.get(this.getcommenturl + '/Comments/GetComment/' + currenttweetid);
      }
      else
        throw new Error('No user id found');
    }
    else
      throw new Error('No user id found');
  }


  private followuserurl = 'http://localhost:5077/api';
  followuser(useridtofollow: number): Observable<any> {
    const loggedinuserid = localStorage.getItem('Userid');

    console.log(loggedinuserid);
    console.log(useridtofollow);
    if (loggedinuserid) {
      let userid = +loggedinuserid;
      const tweetData = { followerid: userid, followingid: useridtofollow };
      return this.http.post(this.followuserurl + '/Followers/PostFollower', tweetData);
    }
    else
      throw new Error('No user id found');
  }

  private getfollowersurl = 'http://localhost:5077/api/Followers/GetFollower/';
  getfollowingusers(): Observable<any> {
    const loggedinuserid = localStorage.getItem('Userid');

    console.log(loggedinuserid);

    if (loggedinuserid) {
      let userid = +loggedinuserid;
      console.log(userid);
      console.log(this.http.get(this.getfollowersurl + '/Followers/GetFollower/' + userid));
      //const tweetData = { followerid: userid, followingid: useridtofollow}; 
      return this.http.get(this.getfollowersurl + userid);

    }
    else
      throw new Error('No user id found');
  }


}


@Injectable({
  providedIn: 'root'
})

export class getuserretweets {
  private apiUrl = 'http://localhost:5077/api/Retweets/GetRetweet/';
  constructor(private http: HttpClient) { }

  getuserretweets(): Observable<any> {

    console.log('invoked createretweets');
    const loggedinuserid = localStorage.getItem('Userid');
    console.log(loggedinuserid);
    if (loggedinuserid) {
      let userid = +loggedinuserid;
      console.log(userid);
      //const tweetData = {userId: userid};    
      return this.http.get(this.apiUrl + userid);
    }
    else
      throw new Error('NO user id found');
  }
}



