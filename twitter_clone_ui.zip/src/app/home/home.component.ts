import { Component } from '@angular/core';
import { CreatetweetService } from '../createtweet.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent {
  tweetText: string = '';

  constructor(private tweetService: CreatetweetService) { }

  submitTweet() {
    console.log("invoked");
    if (this.tweetText.trim() === '') {
      return; // Prevent empty tweets
    }

    this.tweetService.postTweet(this.tweetText).subscribe(
      (response) => {
        console.log('Tweet posted successfully:', response);

      },
      (error) => {
        console.error('Error posting tweet:', error);

      }

    )
  }
}



