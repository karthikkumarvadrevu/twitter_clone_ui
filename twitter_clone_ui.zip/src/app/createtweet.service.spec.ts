import { TestBed } from '@angular/core/testing';

import { CreatetweetService } from './createtweet.service';

describe('CreatetweetService', () => {
  let service: CreatetweetService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CreatetweetService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
