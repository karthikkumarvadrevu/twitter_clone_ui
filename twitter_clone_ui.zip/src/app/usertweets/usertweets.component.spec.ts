import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsertweetsComponent } from './usertweets.component';




describe('UsertweetsComponent', () => {
  let component: UsertweetsComponent;
  let fixture: ComponentFixture<UsertweetsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UsertweetsComponent]
    });
    fixture = TestBed.createComponent(UsertweetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});



