import { Component, Input, OnInit } from '@angular/core';
import { GettweetsService, createretweetService } from '../gettweets.service';
import { Router } from '@angular/router';
//import {createretweetService} from '../gettweets.service';
//import {tweetfunctonalities} from './tweetfunctonalities.component';
//import {TweetfunctonalitiesComponent} from './tweetfunctonalities/tweetfunctonalities.component';


@Component({
  selector: 'app-usertweets',
  templateUrl: './usertweets.component.html',
  styleUrls: ['./usertweets.component.css']
})
export class UsertweetsComponent implements OnInit {
  tweets: any[] = [];
  constructor(private tweetservice: GettweetsService, private router: Router) { }
  ngOnInit() {
    this.tweetservice.getTweetsbyUser()
    .subscribe(
      (response) => {
        console.log(response);
        console.log(localStorage.getItem('UserId'))
        this.tweets = response;
        console.log(this.tweets);
      }
      ,
    )
  }


}


/* @Component({
  selector: 'app-usertweets',
  templateUrl: './usertweets.component.html',
  styleUrls: ['./usertweets.component.css']
})
export class RetweetButtonComponent  {
  @Input() tweetId: number;
   constructor (private tweetservice:createretweetService){} 

   Retweet()
   {
    this.tweetservice.createretweets
    (this.tweetId).subscribe(
      (response) => {
        console.log('Retweet posted successfully:', response);
     },
    
     )
         } */


