import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { UsertweetsComponent } from './usertweets/usertweets.component';
import { AlluserstweetsComponent } from './alluserstweets/alluserstweets.component';
import { getallusertweetsservice } from './gettweets.service';
import { TweetfunctonalitiesComponent } from './tweetfunctonalities/tweetfunctonalities.component';
import { GetuserretweetsComponent } from './getuserretweets/getuserretweets.component';
import { FollowingusersComponent } from './followingusers/followingusers.component';


const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'registration', component: RegistrationComponent },
  { path: 'login', component: LoginComponent },
  { path: 'tweets', component: AlluserstweetsComponent },
  { path: 'tweets/GetTweet', component: UsertweetsComponent },
  { path: 'GetRetweet', component: GetuserretweetsComponent },
  { path: 'GetFollower', component: FollowingusersComponent }


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
