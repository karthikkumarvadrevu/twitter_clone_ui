import { Component, Input } from '@angular/core';
import { GettweetsService } from '../gettweets.service';
import { createretweetService } from '../gettweets.service';

@Component({
  selector: 'app-tweetfunctonalities',
  templateUrl: './tweetfunctonalities.component.html',
  styleUrls: ['./tweetfunctonalities.component.css']
})
export class TweetfunctonalitiesComponent {
  @Input() tweetid: number;
  @Input() commenttext: string = '';
  @Input() userid: number;

  showCommentBox = false;
  likes = 0;
  comments: any[] = [];
  followingusers: any[] = [];

  constructor(private tweetservice: createretweetService) { }

  Retweet() {
    console.log("invoked retweet");
    this.tweetservice.createretweets(this.tweetid).subscribe(
      (response: any) => {
        console.log('Tweet retweeted successfully:', response);
      })
  }

  toggleCommentBox() {
    this.showCommentBox = !this.showCommentBox;
  }

  comment() {
    console.log("invoked comment");
    console.log(this.tweetid);
    this.tweetservice.comment(this.commenttext, this.tweetid).subscribe(
      (response: any) => {
        console.log('Tweet Commented successfully:', response);
        this.showCommentBox = false;
      })
  }

  getcomments() {

    console.log("invoked getcomments");
    this.tweetservice.gettweetcomments(this.tweetid).subscribe(
      (response) => {
        console.log(response);
        this.comments = response;
        console.log(this.comments);

      }
      ,
    )
  }

  followuser() {
    console.log("invoked followuser");
    console.log(this.userid);
    this.tweetservice.followuser(this.userid).subscribe(
      (response: any) => {
        console.log('User followed successfully:', response);

      })
  }

  like() {
    console.log("invoked like");
    this.tweetservice.liketweet(this.tweetid).subscribe(
      (response: any) => {
        console.log('Tweet Liked successfully:', response);
        this.likes++;
      })
  }



}








