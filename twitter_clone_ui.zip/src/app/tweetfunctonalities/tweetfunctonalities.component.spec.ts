import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TweetfunctonalitiesComponent } from './tweetfunctonalities.component';

describe('TweetfunctonalitiesComponent', () => {
  let component: TweetfunctonalitiesComponent;
  let fixture: ComponentFixture<TweetfunctonalitiesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TweetfunctonalitiesComponent]
    });
    fixture = TestBed.createComponent(TweetfunctonalitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
