import { TestBed } from '@angular/core/testing';

import { GettweetsService } from './gettweets.service';
import { getallusertweetsservice } from './gettweets.service';

describe('GettweetsService', () => {
  let service: GettweetsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GettweetsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

describe('getallusertweetsservice', () => {
  let service: getallusertweetsservice;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(getallusertweetsservice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

