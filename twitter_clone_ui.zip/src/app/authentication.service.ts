import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  loginurl: string = "http://localhost:5077/api/Users/Login";
  constructor(private http: HttpClient) { }
  login(email: string, password: string): Observable<any> {
    const body = { email, password }
    return this.http.post(this.loginurl, body);


  }

}
