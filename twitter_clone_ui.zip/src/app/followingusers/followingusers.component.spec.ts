import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FollowingusersComponent } from './followingusers.component';

describe('FollowingusersComponent', () => {
  let component: FollowingusersComponent;
  let fixture: ComponentFixture<FollowingusersComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FollowingusersComponent]
    });
    fixture = TestBed.createComponent(FollowingusersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
