import { Component } from '@angular/core';
import { GettweetsService, createretweetService } from '../gettweets.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-followingusers',
  templateUrl: './followingusers.component.html',
  styleUrls: ['./followingusers.component.css']
})
export class FollowingusersComponent {

  followingusers: any[] = [];

  constructor(private tweetservice: createretweetService, private router: Router) {
    console.log('Inside Constructor');
  }

  ngOnInit() {
    console.log("invoked getfollowingusers");
    this.tweetservice.getfollowingusers().subscribe(
      (response) => {
        console.log(response);
        this.followingusers = response;
        console.log(this.followingusers);
      },
    )
    
  }
}




