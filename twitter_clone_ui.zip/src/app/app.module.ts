import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegistrationComponent } from './registration/registration.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { AlluserstweetsComponent } from './alluserstweets/alluserstweets.component';
import { GettweetsService } from './gettweets.service';
import { getallusertweetsservice } from './gettweets.service';
import { UsertweetsComponent } from './usertweets/usertweets.component';
import { TweetfunctonalitiesComponent } from './tweetfunctonalities/tweetfunctonalities.component';
import { GetuserretweetsComponent } from './getuserretweets/getuserretweets.component';
import { FollowingusersComponent } from './followingusers/followingusers.component';


@NgModule({
  declarations: [
    AppComponent,
    RegistrationComponent,
    HomeComponent,
    LoginComponent,
    UsertweetsComponent,
    AlluserstweetsComponent,
    TweetfunctonalitiesComponent,
    GetuserretweetsComponent,
    FollowingusersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
