import { Component, Input, OnInit } from '@angular/core';
import { GettweetsService, getallusertweetsservice, createretweetService } from '../gettweets.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-alluserstweets',
  templateUrl: './alluserstweets.component.html',
  styleUrls: ['./alluserstweets.component.css'],

})
export class AlluserstweetsComponent {
  [x: string]: any;
  tweets: any[] = [];
  constructor(public tweetservice: getallusertweetsservice, private router: Router) { }

  ngOnInit() {
    console.log('invoked');
    this.tweetservice.getallusertweets()

      .subscribe(
        (response) => {
          console.log(response);
          this.tweets = response;
          localStorage.setItem('tweetid', response.tweetid);
          localStorage.setItem('tweetuserid', response.userid);


        }

      )
  }




}

