import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AlluserstweetsComponent } from './alluserstweets.component';

describe('AlluserstweetsComponent', () => {
  let component: AlluserstweetsComponent;
  let fixture: ComponentFixture<AlluserstweetsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AlluserstweetsComponent]
    });
    fixture = TestBed.createComponent(AlluserstweetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
