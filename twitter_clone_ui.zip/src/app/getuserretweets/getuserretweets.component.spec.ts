import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetuserretweetsComponent } from './getuserretweets.component';

describe('GetuserretweetsComponent', () => {
  let component: GetuserretweetsComponent;
  let fixture: ComponentFixture<GetuserretweetsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GetuserretweetsComponent]
    });
    fixture = TestBed.createComponent(GetuserretweetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
