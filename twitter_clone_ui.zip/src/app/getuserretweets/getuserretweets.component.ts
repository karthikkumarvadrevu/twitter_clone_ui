import { Component, OnInit, Input } from '@angular/core';
import { GettweetsService } from '../gettweets.service';
import { getuserretweets } from '../gettweets.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-getuserretweets',
  templateUrl: './getuserretweets.component.html',
  styleUrls: ['./getuserretweets.component.css']
})
export class GetuserretweetsComponent {
  tweets: any[] = [];
  constructor(private tweetservice: getuserretweets) { }
  ngOnInit() {
    this.tweetservice.getuserretweets().subscribe(
      (response) => {
        console.log(response);
        this.tweets = response;
        console.log(this.tweets);
      }
      ,
    )


  }
}















/* @Component({
  selector: 'app-usertweets',
  templateUrl: '<button (click)="retweet()">Retweet</button>'

})
export class RetweetButtonComponent implements OnInit {
  @Input() tweetId: number;
  constructor (private CreateRetweetService:CreateRetweetService){} 
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
  retweet()
  {
    this.CreateRetweetService.retweet(this.tweetId).subscribe(
      (response) => {
        console.log('Retweet posted successfully:', response);
      }
    
    );
  }
} */













