import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CreatetweetService {
  private apiUrl = 'http://localhost:5077/api';

  constructor(private http: HttpClient) { }

  postTweet(tweetText: string): Observable<any> {
    const loggedinuserid = localStorage.getItem('Userid');
    console.log(loggedinuserid);
    if (loggedinuserid) {
      let userid = +loggedinuserid;
      const tweetData = { tweettext: tweetText, userId: userid };
      return this.http.post(this.apiUrl + '/tweets', tweetData);
    }
    else
      throw new Error('No user id found');
  }




}


