import { Component } from '@angular/core';
import { RegistrationService } from '../registration.service';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {


  password: string = '';
  name: string = '';
  email: string = '';

  constructor(private registrationservice: RegistrationService) { }
  onSubmit() {
    console.log("invoked");
    const user = { username: this.name, password: this.password, email: this.email };
    this.registrationservice.registerUser(user).
      subscribe(
        (response) => {
          console.log('User Registration successful', response);
        },
        (error) => {
          console.log('User Registration failure', error);
        }

      )
  }

}
