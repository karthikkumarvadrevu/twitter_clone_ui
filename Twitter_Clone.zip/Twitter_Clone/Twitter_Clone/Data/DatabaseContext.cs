﻿using Microsoft.EntityFrameworkCore;
using Twitter_Clone.Models;

namespace Twitter_Clone.Data
{
    public class DatabaseContext : DbContext

    {
        public DatabaseContext(DbContextOptions<DatabaseContext> options) : base(options)
        {
        }
        public DbSet<Users> Users { get; set; }
        public DbSet<Tweets> Tweets { get; set; }
        public DbSet<Followers> Followers { get; set; }
        public DbSet<Likes> Likes { get; set; }
        public DbSet<Comments> Comments { get; set; }
        public DbSet<Retweets> Retweets { get; set; } = default!;

    
    }
}
