﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using NuGet.Protocol.Core.Types;
using Twitter_Clone.Data;
using Twitter_Clone.Models;

namespace Twitter_Clone.Controllers
{
    [ApiController]
    [Route("/api/[controller]")]
    public class UsersController : Controller
    {
        private readonly DatabaseContext _context;
        private readonly IConfiguration _config;

        public UsersController(DatabaseContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }
        [HttpPost]
       
        public async Task<ActionResult<Users>> Register(Users user)
        {
            user.registrationdate = DateTime.Now; 
            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            return Ok(user);
        }

        

        [HttpGet]
        [Route("GetAllUsers")]
        public async Task<ActionResult<IEnumerable<Users>>> GetAllUsers()
        {
            return await _context.Users.ToListAsync();
        }

        [HttpPost]
        [Route("Login")]
        public Task<IActionResult> Login([FromBody] Users login)
        {
            IActionResult response = Unauthorized();
            var Users = Authenticateuser_dtls(login);
            if (Users != null)
            {
                var tokenString = GenerateJsonWebToken(Users);
                response = Ok(new { token = tokenString ,userid=Users.UserId});
               
            }
            return Task.FromResult(response);
             

        }

        private Users Authenticateuser_dtls(Users login)
        {

            var Users = _context.Users.FirstOrDefault(u => u.Email == login.Email && u.Password == login.Password);
            return Users;
        }


        private string GenerateJsonWebToken(Users userInfo)
        {
            var secuirtyKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("abcdefghijklmnopqrstuvwrtrtfdfdfdfdfdfdfdfdf"));
            var credentials = new SigningCredentials(secuirtyKey, SecurityAlgorithms.HmacSha256Signature);
            var token = new JwtSecurityToken(
                issuer: _config["JWT:ValidIssuer"],
                audience: _config["JWT:ValidAudience"],
                claims: null,
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: credentials
                               );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

    }
}
