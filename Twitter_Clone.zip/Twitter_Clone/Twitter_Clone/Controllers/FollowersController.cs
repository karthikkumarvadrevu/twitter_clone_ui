﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Twitter_Clone.Data;
using Twitter_Clone.Models;

namespace Twitter_Clone.Controllers
{
    [ApiController]
    [Route("/api/[controller]")]
    public class FollowersController : Controller
    {
        private readonly DatabaseContext _context;

        public FollowersController(DatabaseContext context)
        {
            _context = context;
        }

        // GET: Followers
        [HttpGet]
        [Route("GetAllFollowers")]
        public async Task<ActionResult<IEnumerable<Followers>>> GetAllFollowers()
        {
            return await _context.Followers.ToListAsync();
        }

        [HttpGet]
        [Route("GetFollower/{id}")]
        public ActionResult<IEnumerable<Followers>> GetFollower(int id)
        {
            var follower =  _context.Followers.Where(x=>x.followerid==id).ToList().DistinctBy(x => new { x.followerid, x.FOLLOWINGID });

      

            return Json(follower);


           // var query = from re in _context.Followers
             //           join tw in _context.Users on re.followerid equals tw.UserId
               //         select  new { re.followerid, re.FOLLOWINGID, tw.Username };
            //return Json(query);
        }

        [HttpPost]
        [Route ("PostFollower")]
        public async Task<ActionResult<Followers>> PostFollower(Followers follower)
        {
            _context.Followers.Add(follower);
            await _context.SaveChangesAsync();
            return Ok(follower);

           
        }

      

        [HttpDelete]
        [Route("DeleteFollower/{id}")]
        public async Task<IActionResult> DeleteFollower(int id)
        {
            var follower = await _context.Followers.FindAsync(id);
            if (follower == null)
            {
                return NotFound();
            }

            _context.Followers.Remove(follower);
            await _context.SaveChangesAsync();

            return NoContent();
        }

    }
}
