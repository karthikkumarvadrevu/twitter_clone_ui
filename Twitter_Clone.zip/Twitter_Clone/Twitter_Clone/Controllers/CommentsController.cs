﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Twitter_Clone.Data;
using Twitter_Clone.Models;

namespace Twitter_Clone.Controllers
{
    [ApiController]
    [Route("/api/[controller]")]
    public class CommentsController : Controller
    {
        private readonly DatabaseContext _context;

        public CommentsController(DatabaseContext context)
        {
            _context = context;
        }
        [HttpPost]
        public async Task<ActionResult<Comments>> PostComment(Comments comment)
        {
            comment.commentdate = DateTime.Now;
            _context.Comments.Add(comment);
            await _context.SaveChangesAsync();
            return Ok(comment);
        }

        [HttpPost]
        [Route("PostComment/{id}")]
        public async Task<ActionResult<Comments>> PostComment(int id, Comments comment)
        {
            _context.Comments.Add(comment);
            await _context.SaveChangesAsync();
            return Ok(comment);
        }

        [HttpGet]
        [Route("GetAllComments")]
        public async Task<ActionResult<IEnumerable<Comments>>> GetAllComments()
        {
            return await _context.Comments.ToListAsync();
        }

        [HttpGet]
        [Route("GetComment/{id}")]
        public async Task<ActionResult<List<Comments>>> GetComment(int id)
        {
            var comment = await _context.Comments.Where(x=>x.tweetid==id).ToListAsync();

            if (comment == null)
            {
                return NotFound();
            }

            return comment;
        }

      
    }
}
