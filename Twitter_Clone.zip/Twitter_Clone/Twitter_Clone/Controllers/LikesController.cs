﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Twitter_Clone.Data;
using Twitter_Clone.Models;

namespace Twitter_Clone.Controllers


{
    [ApiController]
    [Route("/api/[controller]")]
    public class LikesController : Controller
    {
        private readonly DatabaseContext _context;

        public LikesController(DatabaseContext context)
        {
            _context = context;
        }

        [HttpGet]
        [Route("GetAllLikes")] 
        public async Task<ActionResult<IEnumerable<Likes>>> GetAllLikes()
        {
            return await _context.Likes.ToListAsync();
        }

        [HttpGet]
        [Route("GetLike/{id}")]
        public async Task<ActionResult<int>> GetLike(int id)
        {
         //  var likecount = await _context.Likes.FindAsync(id);
            int likecount=await _context.Likes.Where(x => x.tweetid == id).CountAsync();      
      

            return likecount;
        }

        [HttpPost]
        [Route("PostLike/{id}")]
        public async Task<ActionResult<Likes>> PostLike(int id, Likes like)
        {
            _context.Likes.Add(like);
            await _context.SaveChangesAsync();
            return Ok(like);
        }

        [HttpPost]
        [Route("PostLike")]
        public async Task<ActionResult<Likes>> PostLike(Likes like)
        {
            _context.Likes.Add(like);
            await _context.SaveChangesAsync();
            return Ok(like);
        }

    
       
    }
}
