﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.CodeAnalysis;
using Microsoft.EntityFrameworkCore;
using Twitter_Clone.Data;
using Twitter_Clone.Models;

namespace Twitter_Clone.Controllers
{
    [ApiController]
    [Route("/api/[controller]")]
    public class RetweetsController : Controller
    {
        private readonly DatabaseContext _context;

        public RetweetsController(DatabaseContext context)
        {
            _context = context;
        }

        [HttpPost]
        [Route("PostRetweet")]
        public async Task<ActionResult<Retweets>> PostRetweet(Retweets retweet)
        {
            retweet.retweetdate = DateTime.Now;
            _context.Retweets.Add(retweet);
            await _context.SaveChangesAsync();
            return Ok(retweet);
        }

        [HttpGet]
        [Route("GetRetweet/{id}")]
        public ActionResult<IEnumerable<Retweets>> GetRetweet(int id)
        {
            var retweet = _context.Retweets.Where(x => x.userid == id).ToList();

            return Json(retweet);
        }

    }
}
