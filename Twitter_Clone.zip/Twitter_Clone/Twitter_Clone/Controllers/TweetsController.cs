﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Twitter_Clone.Data;
using Twitter_Clone.Models;

namespace Twitter_Clone.Controllers
{
    [ApiController]
    [Route("/api/[controller]")]
    public class TweetsController : Controller
    {
        private readonly DatabaseContext _context;

        public TweetsController(DatabaseContext context)
        {
            _context = context;
        }

        [HttpPost]

        public async Task<ActionResult<Tweets>> PostTweet(Tweets tweet)
        {
            tweet.tweetdate = DateTime.Now;
            _context.Tweets.Add(tweet);
            await _context.SaveChangesAsync();
            return Ok(tweet);
        }

        [HttpGet]

        public async Task<ActionResult> GetAllTweets()
           // <List<Tweets>>
        {
            //return await _context.Tweets.ToListAsync();
            var tweet = await _context.Tweets.Include(x => x.User).Select(x => new{x.tweettext,x.tweetid,x.User.Username,x.User.Email,x.tweetdate,x.User.UserId}).ToListAsync();
            
            return Json(tweet);
        }

        [HttpGet]
        [Route("GetTweet/{id}")]

        public async Task<ActionResult<List<Tweets>>> GetTweet(int id)
        {
           // var tweet = await _context.Tweets.FindAsync(id);
            var tweet = await _context.Tweets.Where(x=>x.userid==id).ToListAsync();

            if (tweet == null)
            {
                return NotFound();
            }

            return tweet;
        }

        [HttpPut]
        [Route("UpdateTweet/{id}")]
       public async Task<IActionResult> UpdateTweet(int id, Tweets tweet)
        {
            tweet.tweetdate = DateTime.Now;
            if (id != tweet.tweetid)
            {
                return BadRequest();
            }

            _context.Entry(tweet).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException) when (!TweetExists(id))
            {
                return NotFound();
            }

            return NoContent();
        }

        private bool TweetExists(int id)
        {
            throw new NotImplementedException();
        }
    

        [HttpDelete]
        [Route("DeleteTweet/{id}")]
        public async Task<ActionResult<Tweets>> DeleteTweet(int id)
        {
            var tweet = await _context.Tweets.FindAsync(id);
            if (tweet == null)
            {
                return NotFound();
            }

            _context.Tweets.Remove(tweet);
            await _context.SaveChangesAsync();

            return tweet;
        }


    }
}
