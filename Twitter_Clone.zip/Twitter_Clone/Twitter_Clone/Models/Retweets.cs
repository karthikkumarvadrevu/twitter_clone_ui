﻿using System.ComponentModel.DataAnnotations;

namespace Twitter_Clone.Models
{
    public class Retweets
    {
        [Key]
        public int retweetid { get; set; }
        public int originaltweetid { get; set; }
        public int userid { get; set; }
   
        public DateTime retweetdate { get; set; }

       // public Tweets? tweet { get; set; }
 
   
    }
}
