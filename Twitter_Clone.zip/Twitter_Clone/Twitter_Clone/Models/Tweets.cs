﻿using System.ComponentModel.DataAnnotations;

namespace Twitter_Clone.Models
{
    public class Tweets
    {
        [Key]
        public int tweetid { get; set; }
        public int userid { get; set; }
        public required string tweettext { get; set; }
        public DateTime tweetdate { get; set; }

        public Users? User { get; set; }

    }
}
