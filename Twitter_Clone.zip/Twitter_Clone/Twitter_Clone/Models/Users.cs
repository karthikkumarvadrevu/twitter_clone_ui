﻿using System.ComponentModel.DataAnnotations;

namespace Twitter_Clone.Models
{
    public class Users
    {
        [Key]
        public int UserId { get; set; }
        public  string? Username { get; set; }
        public required string Email { get; set; }
        public required string Password { get; set; }       
        public DateTime registrationdate { get; set; }
    }
}
