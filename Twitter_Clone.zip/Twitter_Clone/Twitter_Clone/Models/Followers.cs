﻿using System.ComponentModel.DataAnnotations;

namespace Twitter_Clone.Models
{
    public class Followers
    {
        [Key]
        public int followerid { get; set; }
        public int FOLLOWINGID { get; set; }
       
    }
}
