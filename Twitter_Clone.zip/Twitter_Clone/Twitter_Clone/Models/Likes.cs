﻿using System.ComponentModel.DataAnnotations;

namespace Twitter_Clone.Models
{
    public class Likes
    {
        [Key]
        public int userid { get; set; }
        public int tweetid { get; set; }
    }
}
