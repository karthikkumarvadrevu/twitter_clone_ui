﻿using System.ComponentModel.DataAnnotations;

namespace Twitter_Clone.Models
{
    public class Comments

    {
        [Key]
        public int commentid { get; set; }
        public int userid { get; set; }
        public int tweetid { get; set; }
  
        public required string commenttext { get; set; }

        public DateTime commentdate { get; set; }
    }
}
